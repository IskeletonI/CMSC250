package edu.lawrence.quiz;

public class Question {
    private int id;
    private String subject;
    private String question;
    private String choices;
    private String answer;
    
    public Question() {
        id = -1;
        subject = "";
        question = "";
        choices = "";
        answer = "";
    }
    
    public Question(String subject,String question,String choices,String answer) {
        this.subject = subject;
        this.question = question;
        this.choices = choices;
        this.answer = answer;
    }
    
    public Question(int id,String subject,String question,String choices,String answer) {
        this.id = id;
        this.subject = subject;
        this.question = question;
        this.choices = choices;
        this.answer = answer;
    }
    
    public int getId() { return id; }
    public String getSubject() { return subject; }
    public String getQuestion() { return question; }
    public String getChoices() { return choices; }
    public String getAnswer() { return answer; }
    
    public void setSubject(String subject) { this.subject = subject; }
    public void setQuestion(String question) { this.question = question; }
    public void setChoices(String choices) { this.choices = choices; }
    public void setAnswer(String answer) { this.answer = answer; }
}
