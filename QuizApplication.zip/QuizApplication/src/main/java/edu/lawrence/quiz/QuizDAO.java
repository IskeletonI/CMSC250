package edu.lawrence.quiz;

import java.sql.*;
import java.time.LocalDate;
import java.util.ArrayList;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;

/**
 *
 * @author Joe Gregg
 */
public class QuizDAO {

    // The constructor opens the database connection
    public QuizDAO() {
        // Load the database driver
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
        } catch (ClassNotFoundException ex) {
            System.out.println("Could not load database driver.");
        }
        // Open the connection and set up statements
        try {
            connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/quiz?user=student&password=Cmsc250!");
            statement = connection.createStatement();
            getQuestionstmt = connection.prepareStatement(getQuestion);
            insertStmt = connection.prepareStatement(insertSQL);
            deleteStmt = connection.prepareStatement(deleteSQL);
        } catch (SQLException ex) {
            System.out.println("Could not connect to database.");
            ex.printStackTrace();
        }

        Questions = FXCollections.observableArrayList();
    }
    public Question getQuestion(int id) {
        Question result = null;
        try {
            getQuestionstmt.setInt(1, id);
            ResultSet resultSet = getQuestionstmt.executeQuery();
            if (resultSet.next()) {
                String subject = resultSet.getString("subject");
                String question = resultSet.getString("question");
                String choices = resultSet.getString("choices");
                String answer = resultSet.getString("answer");
                result = new Question(id,subject,question,choices,answer);
            }
        } catch (SQLException ex) {
            ex.printStackTrace();
        }
        return result;
    }
    public void rebuildQuestions() {
        Questions.clear();
        try {
            getQuestionstmt.setInt(1, currentQuiz);
            ResultSet resultSet = getQuestionstmt.executeQuery();
            while (resultSet.next()) {
                int id = resultSet.getInt("id");
                String subject = resultSet.getString("subject");
                subjects.add(new Subject(id,subject));
            }
        } catch (SQLException ex) {
            ex.printStackTrace();
        }
    }
    
    



  
    private int currentQuiz;
    private Connection connection;
    private Statement statement;
    private String getQuestion = "select question from questions where quiz=?";
    private PreparedStatement getQuestionstmt;
    private String insertSQL = "select choices from questions where quiz=?";
    private PreparedStatement insertStmt;
    private String deleteSQL = "delete from reservations where id=?";
    private PreparedStatement deleteStmt;
    private String room;
    private int capacity;
    private LocalDate date;
    private ObservableList<Question> Questions;
}
