package edu.lawrence.liangclientserver;

import java.io.*;
import java.net.*;
import java.util.Date;
import javafx.application.Application;
import javafx.application.Platform;
import javafx.scene.Scene;
import javafx.scene.control.ScrollPane;
import javafx.scene.control.TextArea;
import javafx.stage.Stage;

public class MultiThreadServer extends Application {
  // Text area for displaying contents
  private TextArea ta = new TextArea();
  private Game gameBoard = new Game();
  
  // Number a client
  private int clientNo = 1;

  @Override // Override the start method in the Application class
  public void start(Stage primaryStage) {
    // Create a scene and place it in the stage
    Scene scene = new Scene(new ScrollPane(ta), 450, 200);
    primaryStage.setTitle("MultiThreadServer"); // Set the stage title
    primaryStage.setScene(scene); // Place the scene in the stage
    primaryStage.show(); // Display the stage

    new Thread( () -> {
      try {
        // Create a server socket
        ServerSocket serverSocket = new ServerSocket(8000);
        ta.appendText("MultiThreadServer started at " 
          + new Date() + '\n');
    
        while (clientNo < 3) {
          // Listen for a new connection request
          Socket socket = serverSocket.accept();
 
    
          
          Platform.runLater( () -> {
            // Display the client number
            ta.appendText("Starting thread for client " + clientNo +
              " at " + new Date() + '\n');

            // Find the client's host name, and IP address
            InetAddress inetAddress = socket.getInetAddress();
            ta.appendText("Client " + clientNo + "'s host name is "
              + inetAddress.getHostName() + "\n");
            ta.appendText("Client " + clientNo + "'s IP Address is "
              + inetAddress.getHostAddress() + "\n");
          });
          
          // Create and start a new thread for the connection
          new Thread(new HandleAClient(socket, clientNo)).start();
          clientNo++;
        }
      }
      catch(IOException ex) {
        System.err.println(ex);
      }
    }).start();
  }
  
  // Define the thread class for handling new connection
  class HandleAClient implements Runnable {
    private Socket socket; // A connected socket
    private int shape;

    /** Construct a thread */
    public HandleAClient(Socket socket, int shape) {
      this.socket = socket;
      this.shape = shape;
    }

    /** Run a thread */
    public void run() {
      try {
        // Create data input and output streams
        DataInputStream inputFromClient = new DataInputStream(
          socket.getInputStream());
        DataOutputStream outputToClient = new DataOutputStream(
          socket.getOutputStream());
        
        outputToClient.writeInt(shape);
        

        // Continuously serve the client
        while (true) {
            int a = inputFromClient.readInt();
            
            switch(a){
                case 1:
                    int loc1 = inputFromClient.readInt();
                    int loc2 = inputFromClient.readInt();
                    char sign = inputFromClient.readChar();
                    int shape = 0;
                    if(sign=='X')
                        shape = 1;
                    else if (sign == 'O')
                        shape = 2;
                    gameBoard.move(loc1, loc2, shape);
                    break;
                case 2:  
                    outputToClient.writeUTF(gameBoard.getGame());
                    outputToClient.writeInt(gameBoard.getGameStatus());
                    break;
            }
        }
      }
      catch(IOException ex) {
        ex.printStackTrace();
      }
    }
  }
    class Game{
        private int[][] board = {{0,0,0},{0,0,0},{0,0,0}};
        private boolean complete = false;
        private int turn = 2;
        
        public Game(){}
        
        public void move(int loc1, int loc2, int shape){
            if(complete){}
            else if(board[loc1][loc2]==0 && turn!=shape){
                board[loc1][loc2]=shape;
                turn = shape;
            }
            else{}
        }
        public String getGame(){
            String stringBoard = turn + "-";
            for(int i = 0; i < 3; i++){
               for(int j = 0; j < 3; j++){
                   stringBoard = stringBoard + board[i][j] + "-";
               }
            }
            return stringBoard;
        }
        public int getGameStatus(){
            for(int i = 0; i < 3; i ++){
                if(board[0][0]==board[1][1]&&board[0][0]==board[2][2]&&board[0][0]!=0){
                    complete = true;
                    return board[0][0];
                }
                else if (board[0][2]==board[1][1]&&board[0][2]==board[2][0]&&board[0][2]!=0){
                    complete = true;
                    return board[0][2];
                }
                else if (board[i][0]==board[i][1]&&board[i][0]==board[i][2]&&board[i][0]!=0){
                    complete = true;
                    return board[i][0];
                }
                else if (board[0][i]==board[1][i]&&board[0][i]==board[2][i]&&board[0][i]!=0){
                    complete = true;
                    return board[0][i];
                }
            }
            return 0;
        }
    }
  
  /**
   * The main method is only needed for the IDE with limited
   * JavaFX support. Not needed for running from the command line.
   */
  public static void main(String[] args) {
    launch(args);
  }
}
