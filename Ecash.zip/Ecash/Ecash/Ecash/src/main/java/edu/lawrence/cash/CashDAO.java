package edu.lawrence.cash;

import java.sql.*;


/**
 *
 * @author Joe Gregg
 */
public class CashDAO {

    // The constructor opens the database connection
    public CashDAO() {
        // Load the database driver
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
        } catch (ClassNotFoundException ex) {
            System.out.println("Could not load database driver.");
        }
        // Open the connection and set up statements
        try {
            connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/ecash?user=student&password=Cmsc250!");
            statement = connection.createStatement();
            getBalanceStmt = connection.prepareStatement(getBalance);
            updateBalanceStmt = connection.prepareStatement(updateBalanceSQL);
            insertStmt = connection.prepareStatement(insertSQL);
        } catch (SQLException ex) {
            System.out.println("Could not connect to database.");
            ex.printStackTrace();
        }

        
        
    }

  
    public int getBalance(int id){
        try{
            getBalanceStmt.setInt(1, id);
            ResultSet resultSet = getBalanceStmt.executeQuery();
            while(resultSet.next()){
                int balance = resultSet.getInt("balance");
                return balance;
            }
        }
        catch(SQLException ex){
            ex.printStackTrace();
        }
        return 0;
    }
    
    public void updateAccount(int amount, int id){
        try{
            updateBalanceStmt.setInt(1,amount);
            updateBalanceStmt.setInt(2, id);
            updateBalanceStmt.execute();
        }
        catch(SQLException ex){
            ex.printStackTrace();
        }
    }

  
    public void writeTo(int amount, int idFrom, int idTo){
        try{
            insertStmt.setInt(1, amount);
            insertStmt.setInt(2, idFrom);
            insertStmt.setInt(3, idTo);
            insertStmt.execute();
        }
        catch (SQLException ex){
            ex.printStackTrace();
        }
        
    }
    
    
    
    



  
    private int currentQuiz;
    private Connection connection;
    private Statement statement;
    private String getBalance = "select balance from accounts where id=?";
    private PreparedStatement getBalanceStmt;
    private String updateBalanceSQL = "update accounts set balance=? where id=?";
    private PreparedStatement updateBalanceStmt;
    private String insertSQL = "insert into transactions(amount, fromAcct, toAcct) values(?, ?, ?)";
    private PreparedStatement insertStmt;
}
