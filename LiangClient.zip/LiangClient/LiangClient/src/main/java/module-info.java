module edu.lawrence.liangclientserver {
    requires javafx.controls;
    exports edu.lawrence.liangclientserver;
}
