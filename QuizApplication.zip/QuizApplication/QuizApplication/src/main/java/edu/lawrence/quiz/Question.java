package edu.lawrence.quiz;

public class Question {
    private int id;
    private String question;
    private String choices;
    private String answer;
    
    public Question() {
        id = -1;
        question = "";
        choices = "";
        answer = "";
    }
    
    public Question(String question,String choices,String answer) {
        this.question = question;
        this.choices = choices;
        this.answer = answer;
    }
    
    public Question(int id,String question,String choices,String answer) {
        this.id = id;
        this.question = question;
        this.choices = choices;
        this.answer = answer;
    }
    
    public int getId() { return id; }
    public String getQuestion() { return question; }
    public String getChoices() { return choices; }
    public String getAnswer() { return answer; }
    
    public void setQuestion(String question) { this.question = question; }
    public void setChoices(String choices) { this.choices = choices; }
    public void setAnswer(String answer) { this.answer = answer; }
    
    public String toString() {
        return question;
    }
}
