package edu.lawrence.mazedrawing;

import java.io.PrintWriter;
import javafx.scene.shape.Line;
import javafx.scene.shape.Shape;

public class Wall {

    private Line line;
    
    private double snap(double x) {
        long n = Math.round(x / 40);
        return n * 40.0;
    }
    
    public Wall(double x, double y) {
        line = new Line();
        line.setStartX(snap(x));
        line.setStartY(snap(y));
        line.setEndX(x);
        line.setEndY(y);
    }
    public Wall(double x, double y, double x2, double y2) {
        line = new Line();
        line.setStartX(x);
        line.setStartY(y);
        line.setEndX(x2);
        line.setEndY(y2);
    }
    
    public Shape getShape() { return line; }
    
    public void setEnd(double x, double y) {
        line.setEndX(x);
        line.setEndY(y);
    }
    
    public void snapToGrid(double x, double y) {
        double deltaX = Math.abs(x - line.getStartX());
        double deltaY = Math.abs(y - line.getStartY());
        if (deltaX > deltaY) {
            line.setEndX(snap(x));
            line.setEndY(line.getStartY());
        } else {
            line.setEndX(line.getStartX());
            line.setEndY(snap(y));
        }
    }
    
    public void write(PrintWriter out) {
        out.println(Math.round(line.getStartX()) + " " + Math.round(line.getStartY())
                + " " + Math.round(line.getEndX()) + " " + Math.round(line.getEndY()));
    }
}
