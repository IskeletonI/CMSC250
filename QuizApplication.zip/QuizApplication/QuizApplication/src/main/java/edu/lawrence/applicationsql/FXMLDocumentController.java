package edu.lawrence.applicationsql;


import edu.lawrence.quiz.Student;
import edu.lawrence.quiz.QuizDAO;
import edu.lawrence.quiz.Question;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.ChoiceBox;
import javafx.scene.control.ListView;
import java.util.ArrayList;
import javafx.scene.control.Label;


public class FXMLDocumentController implements Initializable {
    private QuizDAO dao;
    
    @FXML private ChoiceBox quizC;
    @FXML private ChoiceBox studentC;
    @FXML private ListView questionList;
    @FXML Label labelA;
    @FXML Label labelB;
    @FXML Label labelC;
    @FXML Label labelD;
    @FXML Label errorMessage;
    
    @FXML
    private void A(ActionEvent event) {
        Question selectedQ = (Question) questionList.getSelectionModel().getSelectedItem();
        String selectedS =  (String) studentC.getValue();
        if(dao.choiceButton(selectedQ, selectedS, "a")){
            errorMessage.setText("already have answered it");
        }
        else if ("a".equals(selectedQ.getAnswer())){
            errorMessage.setText("correct");
        }
        else{
            errorMessage.setText("wrong");
        }
    }
    @FXML
    private void B(ActionEvent event) {
        Question selectedQ = (Question) questionList.getSelectionModel().getSelectedItem();
        String selectedS =  (String) studentC.getValue();
        if(dao.choiceButton(selectedQ, selectedS, "b")){
            errorMessage.setText("already have answered it");
        }
        else if ("b".equals(selectedQ.getAnswer())){
            errorMessage.setText("correct");
        }
        else{
            errorMessage.setText("wrong");
        }
    }
    @FXML
    private void C(ActionEvent event) {
        Question selectedQ = (Question) questionList.getSelectionModel().getSelectedItem();
        String selectedS =  (String) studentC.getValue();
        if(dao.choiceButton(selectedQ, selectedS, "c")){
            errorMessage.setText("already have answered it");
        }
        else if ("c".equals(selectedQ.getAnswer())){
            errorMessage.setText("correct");
        }
        else{
            errorMessage.setText("wrong");
        }
    }
    @FXML
    private void D(ActionEvent event) {
        Question selectedQ = (Question) questionList.getSelectionModel().getSelectedItem();
        String selectedS =  (String) studentC.getValue();
        if(dao.choiceButton(selectedQ, selectedS, "d")){
            errorMessage.setText("already have answered it");
        }
        else if ("d".equals(selectedQ.getAnswer())){
            errorMessage.setText("correct");
        }
        else{
            errorMessage.setText("wrong");
        }
    }  

    
    
    private void changeQuiz(Object quiz) {
        if(quiz != null)
            dao.setQuiz(quiz.toString());
    }
    private void changeChoices(Object Question) {
        Question selected = (Question) questionList.getSelectionModel().getSelectedItem();
        if (selected != null){
            String choices = selected.getChoices();
            String parts[] = choices.split(",");
            labelA.setText(parts[0]);
            labelB.setText(parts[1]);
            labelC.setText(parts[2]);
            labelD.setText(parts[3]);
        }
    }
    
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        dao = new QuizDAO();

        ArrayList<String> quizNames = dao.getQuizNames();
        ArrayList<String> studentNames = dao.getStudentNames();
        String quiz = quizNames.get(0);
        String student = studentNames.get(0);
        quizC.getItems().addAll(quizNames);
        quizC.setValue(quiz);
        studentC.getItems().addAll(studentNames);
        studentC.setValue(student);
        quizC.getSelectionModel().selectedItemProperty().addListener((observable, oldValue, newValue)->changeQuiz(newValue));
        questionList.getSelectionModel().selectedItemProperty().addListener((observable, oldValue, newValue)->changeChoices(newValue));
        
        dao.setQuiz(quiz);
        questionList.setItems(dao.getQuestions());
    }
}
