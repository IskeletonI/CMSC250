module edu.lawrence.hotelsql {
    requires javafx.controls;
    requires javafx.fxml;
    requires java.sql;
    
    opens edu.lawrence.hotelsql to javafx.fxml;
    exports edu.lawrence.hotelsql;
}