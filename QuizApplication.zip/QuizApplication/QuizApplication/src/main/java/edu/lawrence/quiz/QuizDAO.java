package edu.lawrence.quiz;

import java.sql.*;
import java.util.ArrayList;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;

/**
 *
 * @author Joe Gregg
 */
public class QuizDAO {

    // The constructor opens the database connection
    public QuizDAO() {
        // Load the database driver
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
        } catch (ClassNotFoundException ex) {
            System.out.println("Could not load database driver.");
        }
        // Open the connection and set up statements
        try {
            connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/quiz?user=student&password=Cmsc250!");
            statement = connection.createStatement();
            getQuestionstmt = connection.prepareStatement(getQuestion);
            quizIDStmt = connection.prepareStatement(quizIDSQL);
            studentStmt = connection.prepareStatement(studentSQL);
            insertStmt = connection.prepareStatement(insertSQL);
        } catch (SQLException ex) {
            System.out.println("Could not connect to database.");
            ex.printStackTrace();
        }

        Questions = FXCollections.observableArrayList();
        
        rebuildQuestions();
    }
    public void rebuildQuestions() {
        Questions.clear();
        try {
            getQuestionstmt.setInt(1, currentQuiz);
            ResultSet resultSet = getQuestionstmt.executeQuery();
            while (resultSet.next()) {
                int id = resultSet.getInt("id");
                String question = resultSet.getString("question");
                String choices = resultSet.getString("choices");
                String answer = resultSet.getString("answer");
                Questions.add(new Question(id, question, choices, answer));
            }
        } catch (SQLException ex) {
            ex.printStackTrace();
        }
    }
    
    public void setQuiz(String quizName) {
        try {
            quizIDStmt.setString(1, quizName);
            ResultSet result = quizIDStmt.executeQuery();
            if(result.next()) {
                currentQuiz = result.getInt(1);
            } else
                currentQuiz = 0;
        }catch (SQLException ex) {
            currentQuiz = 0;
            ex.printStackTrace();
        }
        if(currentQuiz == 0)
            return;
        rebuildQuestions();
    }
    public void choiceButton(Question q, Student s, String choice){
        try {
            studentStmt.setString(1,s.getStudent());
            studentStmt.setString(2, String.valueOf(q.getId()));
            ResultSet result = studentStmt.executeQuery();
            if(result.next()){
                return;
            }
            else{
                insertStmt.setString(1, s.getStudent());
                insertStmt.setString(2, String.valueOf(q.getId()));
                insertStmt.setString(3, choice);
                if(q.getAnswer().equals(choice)){
                    insertStmt.setString(4, "1");
                }
                else{
                    insertStmt.setString(4, "0");
                }
                insertStmt.execute();
            }

            
        } catch (SQLException ex) {
            ex.printStackTrace();
        }
        
    }
    
    
    public ArrayList<String> getQuizNames() {
        ArrayList<String> results = new ArrayList<String>();
        try {
            ResultSet resultSet = statement.executeQuery("select title from quizzes");

            while (resultSet.next()) {
                results.add(resultSet.getString(1));
            }
        } catch (SQLException ex) {
            ex.printStackTrace();
        }
        return results;    
    }
    
    public ArrayList<String> getStudentNames() {
        ArrayList<String> results = new ArrayList<String>();
        try {
            ResultSet resultSet = statement.executeQuery("select name from students");

            while (resultSet.next()) {
                results.add(resultSet.getString(1));
            }
        } catch (SQLException ex) {
            ex.printStackTrace();
        }
        return results;    
    }
    public ObservableList<Question> getQuestions() { return Questions; }
    
    
    
    



  
    private int currentQuiz;
    private Connection connection;
    private Statement statement;
    private String getQuestion = "select id, question, choices, answer from questions where quiz=?";
    private PreparedStatement getQuestionstmt;
    private String quizIDSQL = "select id from quizzes where title=?";
    private PreparedStatement quizIDStmt;
    private String studentSQL = "select id from responses where student=? and question=?";
    private PreparedStatement studentStmt;
    private String insertSQL = "insert into quizzes(student, question, response, correct) values(?, ?, ?, ?)";
    private PreparedStatement insertStmt;
    private ObservableList<Question> Questions;
}
