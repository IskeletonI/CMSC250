package edu.lawrence.cashapp;


import edu.lawrence.cash.CashDAO;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;


public class FXMLDocumentController implements Initializable {
    private CashDAO dao;
    
    @FXML Label label;
    @FXML TextField from;
    @FXML TextField to;
    @FXML TextField amount;

    
     

    @FXML
    private void transferB(ActionEvent event){
        int idF = Integer.parseInt(from.getText());
        int idT = Integer.parseInt(to.getText());
        int Amount = Integer.parseInt(amount.getText());
        if(dao.getBalance(idF) >= Amount) {
            dao.writeTo(Amount, idF, idT);
            dao.updateAccount(dao.getBalance(idT) + Amount, idT);
            dao.updateAccount(dao.getBalance(idF) - Amount, idF);
            label.setText("Transfer successful");
        }
        else{
            label.setText("insufficient funds");
        }
    }
    
    
    
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        dao = new CashDAO();
    }
}
