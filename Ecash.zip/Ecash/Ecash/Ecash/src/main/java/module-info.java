module edu.lawrence.cash {
    requires javafx.controls;
    requires javafx.fxml;
    requires java.sql;
    requires java.base;
    
    opens edu.lawrence.cashapp to javafx.fxml;
    exports edu.lawrence.cashapp;
}