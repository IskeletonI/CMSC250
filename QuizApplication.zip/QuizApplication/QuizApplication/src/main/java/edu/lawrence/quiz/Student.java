package edu.lawrence.quiz;

/**
 *
 * @author juhyoungshin
 */
public class Student {
    private int id;
    private String Student;
    
    public Student(int id,String Student) {
        this.id = id;
        this.Student = Student;
    }
    
    public int getId() { return id; }
    public String getStudent() { return Student; }
    
    public String toString() {
        return Student;
    }
}
