package edu.lawrence.mazedrawing;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.Scanner;
import javafx.scene.input.KeyEvent;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.Pane;
import javafx.scene.paint.Color;
import javafx.scene.shape.Circle;
import javafx.scene.shape.Line;
import javafx.scene.shape.Shape;
import javafx.scene.text.Font;
import javafx.scene.text.Text;

public class MazePane extends Pane {

    private ArrayList<Wall> walls;
    private ArrayList<Treasure> treasure;
    private Wall wall;
    private Treasure placing;
    private Color color;
    private boolean drawingWalls; 
    private Circle circle;
    private int score;
    private Text t1 = new Text(300, 0, "Score: 0");
    private Font font = Font.font ("sans-serif", 12);
    public MazePane() throws FileNotFoundException {
        drawingWalls = true;
        color = Color.RED;
        walls = new ArrayList<Wall>();
        treasure = new ArrayList<Treasure>();
        
        Scanner scan = new Scanner(new File("maze.txt"));
        this.setOnKeyPressed(e -> keyPress(e));
        int fWall = scan.nextInt();
        for(int i = 0; i < fWall;i++){
            double startX = scan.nextInt();
            double startY = scan.nextInt();
            double endX = scan.nextInt();
            double endY = scan.nextInt();
            wall = new Wall(startX, startY, endX, endY);
            walls.add(wall);
            this.getChildren().add(wall.getShape());
        }
        int fTreasure = scan.nextInt();
        for(int i = 0; i < fTreasure;i++){
            double X = scan.nextInt();
            double Y = scan.nextInt();
            String sColor = scan.next();
            color = Color.web(sColor);
            placing = new Treasure(X, Y, color);
            treasure.add(placing);
            this.getChildren().add(placing.getShape());
        }
        circle = new Circle();
        circle.setCenterX(100);
        circle.setCenterY(60);
        circle.setRadius(10);
        circle.setFill(Color.web("black"));
        this.getChildren().add(circle);
        t1.setFont(font);
        this.getChildren().add(t1);
    }


    public void keyPress(KeyEvent e) {
        double startX = circle.getCenterX();
        double startY = circle.getCenterY();
        double endX = circle.getCenterX();
        double endY = circle.getCenterY();
        boolean cross = false;
        Line l = (Line) wall.getShape();

        switch (e.getCode()) {
            case RIGHT:
                endX = circle.getCenterX()+40;
                wall = new Wall(startX, startY, endX, endY);
                this.getChildren().add(wall.getShape());
                l = (Line) wall.getShape();
                for(Wall w : walls) {
                    if(w != wall) {
                        Shape intersection = Shape.intersect(w.getShape(), l);
                        if(intersection.getBoundsInLocal().getWidth() > 0){
                            cross = true;
                        }
                    }
                }
                if (circle.getCenterX() >= 620 || cross == true) {
                    break;
                }
                else {
                    circle.setCenterX(circle.getCenterX()+40);
                    break;
                }
            case LEFT:
                endX = circle.getCenterX()-40;
                wall = new Wall(startX, startY, endX, endY);
                this.getChildren().add(wall.getShape());
                l = (Line) wall.getShape();
                for(Wall w : walls) {
                    if(w != wall) {
                        Shape intersection = Shape.intersect(w.getShape(), l);
                        if(intersection.getBoundsInLocal().getWidth() > 0){
                            cross = true;
                        }
                    }
                }
                if (circle.getCenterX() <= 20|| cross == true){
                    break;
                }
                else {
                    circle.setCenterX(circle.getCenterX()-40);
                    break;
                }
            case UP:
                endY = circle.getCenterY()-40;
                wall = new Wall(startX, startY, endX, endY);
                this.getChildren().add(wall.getShape());
                l = (Line) wall.getShape();
                for(Wall w : walls) {
                    if(w != wall) {
                        Shape intersection = Shape.intersect(w.getShape(), l);
                        if(intersection.getBoundsInLocal().getWidth() > 0){
                            cross = true;
                        }
                    }
                }
                if (circle.getCenterY() <= 20|| cross == true){
                    break;
                }
                else {
                    circle.setCenterY(circle.getCenterY()-40);
                    break;
                }
            case DOWN:
                endY = circle.getCenterY()+40;
                wall = new Wall(startX, startY, endX, endY);
                this.getChildren().add(wall.getShape());
                l = (Line) wall.getShape();
                for(Wall w : walls) {
                    if(w != wall) {
                        Shape intersection = Shape.intersect(w.getShape(), l);
                        if(intersection.getBoundsInLocal().getWidth() > 0){
                            cross = true;
                        }
                    }
                }
                if (circle.getCenterY() >= 420|| cross == true){
                    break;
                }
                else {
                    circle.setCenterY(circle.getCenterY()+40);
                    break;
                }
        }
        for(Treasure T : treasure) {
            Shape intersection = Shape.intersect(T.getShape(), circle);
            if(intersection.getBoundsInLocal().getWidth() > 0){
                    if (T.getColor() == Color.RED) {
                        score += 100;
                    }
                    else if (T.getColor() == Color.GREEN){
                        score += 40;
                    }
                    else {
                        score += 10;
                    }
                this.getChildren().remove(t1);
                t1 = new Text(300, 0, "Score: " + score);
                t1.setFont(font);
                this.getChildren().add(t1);
                this.getChildren().remove(T.getShape());
                treasure.remove(T);
            }
        }
    }

}
