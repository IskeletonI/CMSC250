package physicsdemo;

import java.io.*;
import java.net.*;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantLock;
import javafx.application.Application;
import javafx.application.Platform;
import javafx.scene.Scene;
import javafx.scene.control.ScrollPane;
import javafx.scene.control.TextArea;
import javafx.scene.paint.Color;
import javafx.scene.shape.Rectangle;
import javafx.scene.shape.Shape;
import javafx.stage.Stage;
import physics.LineSegment;
import physics.Point;
import physics.Ray;
import simulation.Ball;
import simulation.Box;


public class MultiThreadServer extends Application {
  // Text area for displaying contents
  private TextArea ta = new TextArea();
  private Simulation sim = new Simulation(300, 250, 2 ,2);
  
  
  // Number a client
  private int clientNo = 1;

  @Override // Override the start method in the Application class
  public void start(Stage primaryStage) {
    sim.setUpShapes();
    Scene scene = new Scene(new ScrollPane(ta), 450, 200);
    primaryStage.setTitle("MultiThreadServer"); // Set the stage title
    primaryStage.setScene(scene); // Place the scene in the stage
    primaryStage.show(); // Display the stage

    new Thread( () -> {
      try {
        // Create a server socket
        ServerSocket serverSocket = new ServerSocket(8000);
        ta.appendText("MultiThreadServer started at " 
          + new Date() + '\n');
    
        while (clientNo < 3) {
          // Listen for a new connection request
          Socket socket = serverSocket.accept();
 
    
          
          Platform.runLater( () -> {
            // Display the client number
            ta.appendText("Starting thread for client " + clientNo +
              " at " + new Date() + '\n');

            // Find the client's host name, and IP address
            InetAddress inetAddress = socket.getInetAddress();
            ta.appendText("Client " + clientNo + "'s host name is "
              + inetAddress.getHostName() + "\n");
            ta.appendText("Client " + clientNo + "'s IP Address is "
              + inetAddress.getHostAddress() + "\n");
          });
          
          // Create and start a new thread for the connection
          new Thread(new HandleAClient(socket, clientNo)).start();
          if(clientNo ==2){
            new Thread(() -> {
            while (true) {
                sim.evolve(1.0);
                Platform.runLater(()->sim.updateShapes());
                try {
                    Thread.sleep(20);
                } catch (InterruptedException ex) {

                }
            }
            }).start();
            }
            clientNo++;
        }
      }
      catch(IOException ex) {
        System.err.println(ex);
      }
    }).start();
  }
  
  // Define the thread class for handling new connection
  class HandleAClient implements Runnable {
    private Socket socket; // A connected socket
    private int shape;

    /** Construct a thread */
    public HandleAClient(Socket socket, int shape) {
      this.socket = socket;
      this.shape = shape;
    }

    /** Run a thread */
    public void run() {
      try {
        // Create data input and output streams
        DataInputStream inputFromClient = new DataInputStream(
          socket.getInputStream());
        DataOutputStream outputToClient = new DataOutputStream(
          socket.getOutputStream());
       
        

        // Continuously serve the client
        while (true) {
            int a = inputFromClient.readInt();
            
            switch(a){
                case 1:
                    sim.moveInner(0, 5, shape);
                    break;
                case 2:
                    sim.moveInner(0, -5, shape);
                    break;
                case 3:  
                    //frequent check\
                    outputToClient.writeDouble(sim.getOuter().getLocation().x);
                    outputToClient.writeDouble(sim.getOuter().getLocation().y);
                    outputToClient.writeDouble(sim.getInner().getLocation().x);
                    outputToClient.writeDouble(sim.getInner().getLocation().y);
                    outputToClient.writeDouble(sim.getInner2().getLocation().x);
                    outputToClient.writeDouble(sim.getInner2().getLocation().y);
                    outputToClient.writeDouble(sim.getBall().getLocation().x);
                    outputToClient.writeDouble(sim.getBall().getLocation().y);
                    outputToClient.writeInt(Box.leftScore);
                    outputToClient.writeInt(Box.rightScore);
                    
                    break;
            }
        }
      }
      catch(IOException ex) {
        ex.printStackTrace();
      }
    }
  }
 
 public class Simulation{
    private Box outer;
    private Ball ball;
    private Box inner;
    private Box inner2;
    private Lock lock;
    private int score;
    
    public Simulation(int width,int height,int dX,int dY)
    {
        outer = new Box(0,0,width,height,false);
        ball = new Ball(width/2,height/2,dX,dY);
        inner = new Box(width - 50,height - 60, 10, 50,true);
        inner2 = new Box(40, 20, 10, 50,true);
        lock = new ReentrantLock();
    }
    public Box getOuter(){return outer;}
    public Box getInner(){return inner;}
    public Box getInner2(){return inner2;}
    public Ball getBall(){return ball;}
    
    public void evolve(double time)
    {
        lock.lock();
        Ray newLoc = inner.bounceRay(ball.getRay(), time);
        Ray newLoc2 = inner2.bounceRay(ball.getRay(), time);
        if(newLoc != null)
            ball.setRay(newLoc);
        else if (newLoc2 != null){
            ball.setRay(newLoc2);
        }
        else {
            newLoc = outer.bounceRay(ball.getRay(), time);
            if(newLoc != null){
                ball.setRay(newLoc);
                score++;
            }
            else
                ball.move(time);
        } 
        lock.unlock();
    }
    public int getScore(){
        return score;
    }
    
    public void moveInner(int deltaX,int deltaY, int clientNumber)
    {
        if(clientNumber == 1){
            lock.lock();
            int dX = deltaX;
            int dY = deltaY;
            if(inner.x + deltaX < 0)
              dX = -inner.x;
            if(inner.x + inner.width + deltaX > outer.width)
              dX = outer.width - inner.width - inner.x;
            
            if(inner.y + deltaY < 0)
               dY = -inner.y;
            if(inner.y + inner.height + deltaY > outer.height)
               dY = outer.height - inner.height - inner.y;

            inner.move(dX,dY);
            if(inner.contains(ball.getRay().origin)) {
                // If we have discovered that the box has just jumped on top of
                // the ball, we nudge them apart until the box no longer
                // contains the ball.
                int bumpX = -1;
                if(dX < 0) bumpX = 1;
                int bumpY = -1;
                if(dY < 0) bumpY = 1;
                do {
                inner.move(bumpX, bumpY);
                ball.getRay().origin.x += -bumpX;
                ball.getRay().origin.y += -bumpY;
                } while(inner.contains(ball.getRay().origin));
            }
            lock.unlock();
        }
        else if(clientNumber == 2){
            lock.lock();
            int dX = deltaX;
            int dY = deltaY;
            if(inner2.x + deltaX < 0)
              dX = -inner2.x;
            if(inner2.x + inner2.width + deltaX > outer.width)
              dX = outer.width - inner2.width - inner2.x;
            
            if(inner2.y + deltaY < 0)
               dY = -inner2.y;
            if(inner2.y + inner2.height + deltaY > outer.height)
               dY = outer.height - inner2.height - inner2.y;

            inner2.move(dX,dY);
            if(inner2.contains(ball.getRay().origin)) {
                // If we have discovered that the box has just jumped on top of
                // the ball, we nudge them apart until the box no longer
                // contains the ball.
                int bumpX = -1;
                if(dX < 0) bumpX = 1;
                int bumpY = -1;
                if(dY < 0) bumpY = 1;
                do {
                inner2.move(bumpX, bumpY);
                ball.getRay().origin.x += -bumpX;
                ball.getRay().origin.y += -bumpY;
                } while(inner2.contains(ball.getRay().origin));
            }
            lock.unlock();
        }
    }
    
    public List<Shape> setUpShapes()
    {
        ArrayList<Shape> newShapes = new ArrayList<Shape>();
        newShapes.add(outer.getShape());
        newShapes.add(inner.getShape());
        newShapes.add(inner2.getShape());
        newShapes.add(ball.getShape());
        return newShapes;
    }
    
    public void updateShapes()
    {
        inner.updateShape();
        inner2.updateShape();
        ball.updateShape();
    }
}
 


  /**
   * The main method is only needed for the IDE with limited
   * JavaFX support. Not needed for running from the command line.
   */
  public static void main(String[] args) {
    launch(args);
  }
}
