package physicsdemo;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.net.Socket;
import java.util.ArrayList;
import javafx.application.Application;
import javafx.application.Platform;
import javafx.scene.Scene;
import javafx.scene.control.Label;
import static javafx.scene.input.KeyCode.DOWN;
import static javafx.scene.input.KeyCode.UP;
import javafx.scene.layout.BorderPane;
import javafx.scene.paint.Color;
import javafx.stage.Stage;
import javafx.scene.shape.Circle;
import javafx.scene.shape.Rectangle;
import javafx.scene.shape.Shape;


/**
 * JavaFX App
 */
public class App extends Application {
  DataOutputStream toServer = null;
  DataInputStream fromServer = null;
  Rectangle r;
  Circle c;
  GamePane root = new GamePane();

  @Override // Override the start method in the Application class
  public void start(Stage primaryStage) {
    BorderPane mainPane = new BorderPane();

    mainPane.setTop(new Label("s"));
    mainPane.setCenter(root);

    Scene scene = new Scene(mainPane, 300, 280);
    primaryStage.setTitle("pong game"); // Set the stage title
    primaryStage.setScene(scene); // Place the scene in the stage
    primaryStage.setOnCloseRequest((event)->System.exit(0));
    primaryStage.show(); // Display the stage
    

    mainPane.setOnKeyPressed(e -> {
        try{
            switch (e.getCode()) {
                case DOWN:
                    toServer.writeInt(1); toServer.flush();
                    break;
                case UP:
                    toServer.writeInt(2); toServer.flush();
                    break;
            }
        }
        catch(IOException ex){
            ex.printStackTrace();
        }
    });
    
    
  
    try {
      Socket socket = new Socket("localhost", 8000);

      fromServer = new DataInputStream(socket.getInputStream());

      toServer = new DataOutputStream(socket.getOutputStream());
      

      Runnable check = new frequentCheck(socket);
      Thread thread1 = new Thread(check);
      thread1.start();
        
        
    }
    catch (IOException ex) {
      ex.printStackTrace();
    }
    
  }
  class frequentCheck implements Runnable {
      Socket socket;
      public frequentCheck(Socket socket){
          this.socket = socket;
      }
      public void run(){
        try{
            while(true){
                toServer.writeInt(3); toServer.flush();
                ArrayList<Shape> newShapes = new ArrayList<Shape>();
                r = new Rectangle(fromServer.readDouble(),fromServer.readDouble(), 300, 250);
                r.setFill(Color.WHITE);
                r.setStroke(Color.BLACK);
                newShapes.add(r);
                r = new Rectangle(fromServer.readDouble(),fromServer.readDouble(), 20, 30);
                r.setFill(Color.WHITE);
                r.setStroke(Color.BLACK);
                newShapes.add(r);
                r = new Rectangle(fromServer.readDouble(),fromServer.readDouble(), 20, 30);
                r.setFill(Color.WHITE);
                r.setStroke(Color.BLACK);
                newShapes.add(r);
                c = new Circle(fromServer.readDouble(),fromServer.readDouble(), 4);
                c.setFill(Color.RED);
                newShapes.add(c);
                Platform.runLater( () -> {
                    root.setShapes(newShapes);
                });
                
                
                try{
                    Thread.sleep(50);
                }
                catch(InterruptedException ex){
                    ex.printStackTrace();
                }
                
            }
        }
        catch(IOException ex){
            ex.printStackTrace();
        }
      }
    }
  

    public static void main(String[] args) {
        launch();
    }

}