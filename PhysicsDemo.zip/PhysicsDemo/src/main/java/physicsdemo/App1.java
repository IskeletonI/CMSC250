package physicsdemo;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import static java.lang.Thread.sleep;
import java.net.Socket;
import javafx.application.Application;
import javafx.application.Platform;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextArea;
import static javafx.scene.input.KeyCode.DOWN;
import static javafx.scene.input.KeyCode.LEFT;
import static javafx.scene.input.KeyCode.RIGHT;
import static javafx.scene.input.KeyCode.UP;
import javafx.scene.layout.BorderPane;
import javafx.stage.Stage;
import simulation.Simulation;


/**
 * JavaFX App
 */
public class App1 extends Application {

    // IO streams
  DataOutputStream toServer = null;
  DataInputStream fromServer = null;
  private int sign;
  private String shape;

  

  @Override // Override the start method in the Application class
  public void start(Stage primaryStage) {
    // Panel p to hold the label and text field
    BorderPane mainPane = new BorderPane();
    GamePane root = new GamePane();
    Simulation sim = new Simulation(300, 250, 2, 2);
    root.setShapes(sim.setUpShapes());

    mainPane.setTop(new Label("s"));
    mainPane.setCenter(root);

    Scene scene = new Scene(mainPane, 300, 280);
    primaryStage.setTitle("pong game"); // Set the stage title
    primaryStage.setScene(scene); // Place the scene in the stage
    primaryStage.setOnCloseRequest((event)->System.exit(0));
    primaryStage.show(); // Display the stage
    

    mainPane.setOnKeyPressed(e -> {
        try{
            switch (e.getCode()) {
                case DOWN:
                    toServer.writeInt(1); toServer.flush();
                    break;
                case UP:
                    toServer.writeInt(2); toServer.flush();
                    break;
            }
        }
        catch(IOException ex){
            ex.printStackTrace();
        }
    });
    
    
  
    try {
      Socket socket = new Socket("143.44.71.180.", 8000);

      fromServer = new DataInputStream(socket.getInputStream());

      toServer = new DataOutputStream(socket.getOutputStream());
      

      Runnable check = new frequentCheck(socket);
      Thread thread1 = new Thread(check);
      thread1.start();
        
        
    }
    catch (IOException ex) {
      ex.printStackTrace();
    }
    
  }
  class frequentCheck implements Runnable {
      Socket socket;
      public frequentCheck(Socket socket){
          this.socket = socket;
      }
      public void run(){
        try{
            while(true){
                toServer.writeInt(3); toServer.flush();
                String gameBoard = fromServer.readUTF();
                int gameStatus = fromServer.readInt();
                String parts[] = gameBoard.split("-");
                Platform.runLater( () -> {
                    });
                try{
                    Thread.sleep(50);
                }
                catch(InterruptedException ex){
                    ex.printStackTrace();
                }
                
            }
        }
        catch(IOException ex){
            ex.printStackTrace();
        }
      }
    }
  

    public static void main(String[] args) {
        launch();
    }

}