package edu.lawrence.hotelsql;

import java.net.URL;
import java.time.LocalDate;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.ChoiceBox;
import javafx.scene.control.DatePicker;
import javafx.scene.control.ListView;
import edu.lawrence.quiz.QuizDAO;
import edu.lawrence.quiz.Quiz;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import javafx.application.Platform;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Modality;
import javafx.stage.Stage;
import javafx.stage.StageStyle;

/**
 *
 * @author Joe Gregg
 */
public class FXMLDocumentController implements Initializable {
    private QuizDAO dao;
    
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        
    }
   
    
}
