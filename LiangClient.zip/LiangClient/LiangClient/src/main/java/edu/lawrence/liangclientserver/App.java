package edu.lawrence.liangclientserver;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.net.Socket;
import javafx.application.Application;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.ScrollPane;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;


/**
 * JavaFX App
 */
public class App extends Application {

    // IO streams
  DataOutputStream toServer = null;
  DataInputStream fromServer = null;

  @Override // Override the start method in the Application class
  public void start(Stage primaryStage) {
    // Panel p to hold the label and text field
    BorderPane borderPane1 = new BorderPane();
    borderPane1.setLeft(new Label("You are player x"));
    borderPane1.setRight(new Label("Other Player's turn"));
    borderPane1.setPadding(new Insets(20, 20, 20, 20)); 
    BorderPane borderPane2 = new BorderPane();
    borderPane2.setPadding(new Insets(20, 40, 20, 40));
    Button bt = new Button();
    Button bt2 = new Button();
    Button bt3 = new Button();
    bt.setPadding(new Insets(0,15,20,15));
    bt2.setPadding(new Insets(0,15,20,15));
    bt3.setPadding(new Insets(0,15,20,15));
    borderPane2.setStyle("-fx-border-color: green");
    borderPane2.setLeft(bt);
    borderPane2.setCenter(bt2);
    borderPane2.setRight(bt3);
    BorderPane borderPane3 = new BorderPane();
    borderPane3.setPadding(new Insets(20, 40, 20, 40));
    Button bt4 = new Button();
    Button bt5 = new Button();
    Button bt6 = new Button();
    bt4.setPadding(new Insets(0,15,20,15));
    bt5.setPadding(new Insets(0,15,20,15));
    bt6.setPadding(new Insets(0,15,20,15));
    borderPane3.setStyle("-fx-border-color: green");
    borderPane3.setLeft(bt4);
    borderPane3.setCenter(bt5);
    borderPane3.setRight(bt6);
    BorderPane borderPane4 = new BorderPane();
    borderPane4.setPadding(new Insets(20, 40, 20, 40));
    Button bt7 = new Button();
    Button bt8 = new Button();
    Button bt9 = new Button();
    bt7.setPadding(new Insets(0,15,20,15));
    bt8.setPadding(new Insets(0,15,20,15));
    bt9.setPadding(new Insets(0,15,20,15));
    borderPane4.setStyle("-fx-border-color: green");
    borderPane4.setLeft(bt7);
    borderPane4.setCenter(bt8);
    borderPane4.setRight(bt9);
    BorderPane gamePane = new BorderPane();
    gamePane.setTop(borderPane2);
    gamePane.setCenter(borderPane3);
    gamePane.setBottom(borderPane4);
    BorderPane mainPane = new BorderPane();

    mainPane.setPadding(new Insets(20,20,20,20));
    // Text area to display contents
    TextArea ta = new TextArea();
    //mainPane.setRight(bt);
    
    mainPane.setTop(borderPane1);
    mainPane.setCenter(gamePane);
    
    // Create a scene and place it in the stage
    Scene scene = new Scene(mainPane, 450, 330);
    primaryStage.setTitle("Client"); // Set the stage title
    primaryStage.setScene(scene); // Place the scene in the stage
    primaryStage.show(); // Display the stage

    
    bt.setOnAction(e -> {
        borderPane1.setLeft(new Label("s"));
      /*try {
        // Get the radius from the text field
        borderPane1.setLeft(new Label("s"));
  

      }
      catch (IOException ex) {
        System.err.println(ex);
      }*/
    });
  
    try {
      // Create a socket to connect to the server
      Socket socket = new Socket("localhost", 8000);
      // Socket socket = new Socket("130.254.204.36", 8000);
      // Socket socket = new Socket("drake.Armstrong.edu", 8000);

      // Create an input stream to receive data from the server
      fromServer = new DataInputStream(socket.getInputStream());

      // Create an output stream to send data to the server
      toServer = new DataOutputStream(socket.getOutputStream());
      
      int sign = fromServer.readInt();
        if (sign == 1){
            borderPane1.setLeft(new Label("You are player O"));
        }
        else {
            borderPane1.setLeft(new Label("You are player X"));
        }
    }
    catch (IOException ex) {
      ta.appendText(ex.toString() + '\n');
    }
  }

    public static void main(String[] args) {
        launch();
    }

}