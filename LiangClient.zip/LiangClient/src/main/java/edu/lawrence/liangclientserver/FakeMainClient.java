/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package edu.lawrence.liangclientserver;

/**
 *
 * @author joegregg
 */
public class FakeMainClient {
    public static void main(String[] args) {
        App.main(args);
    }
}
