module edu.lawrence.physicsdemo {
    requires javafx.controls;
    exports physicsdemo;
}
