package edu.lawrence.mazedrawing;

import java.io.FileNotFoundException;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.application.Platform;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.layout.VBox;

public class PrimaryController implements Initializable {
    @FXML
    private VBox vBox;
    private MazePane maze;
    
    @FXML
    private void exit() {
        Platform.exit();
    }
    
    
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        try {
            maze = new MazePane();
        } catch (FileNotFoundException ex) {
            ex.printStackTrace();
        }
        maze.setPrefSize(640, 440);
        vBox.getChildren().add(maze);
    }  
    
    public void focusMaze() {
        maze.requestFocus();
    }
}
