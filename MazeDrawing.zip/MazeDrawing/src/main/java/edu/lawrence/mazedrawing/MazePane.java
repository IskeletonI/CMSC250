package edu.lawrence.mazedrawing;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.Scanner;
import javafx.scene.input.KeyEvent;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.Pane;
import javafx.scene.paint.Color;
import javafx.scene.shape.Circle;
import javafx.scene.shape.Line;
import javafx.scene.shape.Shape;

public class MazePane extends Pane {

    private ArrayList<Wall> walls;
    private ArrayList<Treasure> treasure;
    private Wall wall;
    private Treasure placing;
    private Color color;
    private boolean drawingWalls; 
    private Circle circle;
    public MazePane() throws FileNotFoundException {
        drawingWalls = true;
        color = Color.RED;
        walls = new ArrayList<Wall>();
        treasure = new ArrayList<Treasure>();
        
        Scanner scan = new Scanner(new File("maze.txt"));
        this.setOnKeyPressed(e -> keyPress(e));
        int fWall = scan.nextInt();
        for(int i = 0; i < fWall;i++){
            double startX = scan.nextInt();
            double startY = scan.nextInt();
            double endX = scan.nextInt();
            double endY = scan.nextInt();
            wall = new Wall(startX, startY, endX, endY);
            this.getChildren().add(wall.getShape());
        }
        int fTreasure = scan.nextInt();
        for(int i = 0; i < fTreasure;i++){
            double X = scan.nextInt();
            double Y = scan.nextInt();
            String sColor = scan.next();
            color = Color.web(sColor);
            placing = new Treasure(X, Y, color);
            this.getChildren().add(placing.getShape());
        }
        circle = new Circle();
        circle.setCenterX(100);
        circle.setCenterY(60);
        circle.setRadius(10);
        circle.setFill(Color.web("black"));
        this.getChildren().add(circle);
    }


    public void keyPress(KeyEvent e) {
        switch (e.getCode()) {
            case RIGHT:
                circle.setCenterX(circle.getCenterX()+40);
                break;
            case LEFT:
                circle.setCenterX(circle.getCenterX()-40);
                break;
            case UP:
                circle.setCenterY(circle.getCenterY()-40);
                break;
            case DOWN:
                circle.setCenterY(circle.getCenterY()+40);
                break;
        }
    }

}
