package edu.lawrence.liangclientserver;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import static java.lang.Thread.sleep;
import java.net.Socket;
import javafx.application.Application;
import javafx.application.Platform;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextArea;
import javafx.scene.layout.BorderPane;
import javafx.stage.Stage;


/**
 * JavaFX App
 */
public class App extends Application {

    // IO streams
  DataOutputStream toServer = null;
  DataInputStream fromServer = null;
  private int sign;
  private String shape;
  BorderPane borderPane1 = new BorderPane();
  BorderPane borderPane2 = new BorderPane();
  Button bt1 = new Button();
  Button bt2 = new Button();
  Button bt3 = new Button();
  Button bt4 = new Button();
  Button bt5 = new Button();
  Button bt6 = new Button();
  Button bt7 = new Button();
  Button bt8 = new Button();
  Button bt9 = new Button();
  

  @Override // Override the start method in the Application class
  public void start(Stage primaryStage) {
    // Panel p to hold the label and text field
    borderPane1.setLeft(new Label("Game Full"));
    borderPane1.setRight(new Label(""));
    borderPane1.setPadding(new Insets(20, 20, 20, 20)); 
    borderPane2.setPadding(new Insets(20, 40, 20, 40));
    borderPane2.setStyle("-fx-border-color: green");
    borderPane2.setLeft(bt1);
    borderPane2.setCenter(bt2);
    borderPane2.setRight(bt3);
    BorderPane borderPane3 = new BorderPane();
    borderPane3.setPadding(new Insets(20, 40, 20, 40));
    borderPane3.setStyle("-fx-border-color: green");
    borderPane3.setLeft(bt4);
    borderPane3.setCenter(bt5);
    borderPane3.setRight(bt6);
    BorderPane borderPane4 = new BorderPane();
    borderPane4.setPadding(new Insets(20, 40, 20, 40));
    borderPane4.setStyle("-fx-border-color: green");
    borderPane4.setLeft(bt7);
    borderPane4.setCenter(bt8);
    borderPane4.setRight(bt9);
    BorderPane gamePane = new BorderPane();
    gamePane.setTop(borderPane2);
    gamePane.setCenter(borderPane3);
    gamePane.setBottom(borderPane4);
    BorderPane mainPane = new BorderPane();

    mainPane.setPadding(new Insets(20,20,20,20));
    // Text area to display contents
    TextArea ta = new TextArea();
    //mainPane.setRight(bt);
    
    mainPane.setTop(borderPane1);
    mainPane.setCenter(gamePane);
    
    // Create a scene and place it in the stage
    Scene scene = new Scene(mainPane, 350, 300);
    primaryStage.setTitle("Client"); // Set the stage title
    primaryStage.setScene(scene); // Place the scene in the stage
    primaryStage.show(); // Display the stage
    

    
    bt1.setOnAction(e -> {
      try {
        toServer.writeInt(1); toServer.flush();
        toServer.writeInt(0); toServer.writeInt(0); toServer.writeChar(shape.charAt(0)); toServer.flush();
      }
      catch (IOException ex) {
        System.err.println(ex);
      }
    });
    bt2.setOnAction(e ->{
        try {
        toServer.writeInt(1); toServer.flush();
        toServer.writeInt(0); toServer.writeInt(1); toServer.writeChar(shape.charAt(0)); toServer.flush();
      }
      catch (IOException ex) {
        System.err.println(ex);
      }
    });
    bt3.setOnAction(e ->{
        try {
        toServer.writeInt(1); toServer.flush();
        toServer.writeInt(0); toServer.writeInt(2); toServer.writeChar(shape.charAt(0)); toServer.flush();
      }
      catch (IOException ex) {
        System.err.println(ex);
      }
    });
    bt4.setOnAction(e ->{
        try {
        toServer.writeInt(1); toServer.flush();
        toServer.writeInt(1); toServer.writeInt(0); toServer.writeChar(shape.charAt(0)); toServer.flush();
      }
      catch (IOException ex) {
        System.err.println(ex);
      }
    });
    bt5.setOnAction(e ->{
        try {
        toServer.writeInt(1); toServer.flush();
        toServer.writeInt(1); toServer.writeInt(1); toServer.writeChar(shape.charAt(0)); toServer.flush();
      }
      catch (IOException ex) {
        System.err.println(ex);
      }
    });
    bt6.setOnAction(e ->{
        try {
        toServer.writeInt(1); toServer.flush();
        toServer.writeInt(1); toServer.writeInt(2); toServer.writeChar(shape.charAt(0)); toServer.flush();
      }
      catch (IOException ex) {
        System.err.println(ex);
      }
    });
    bt7.setOnAction(e ->{
      try {
        toServer.writeInt(1); toServer.flush();
        toServer.writeInt(2); toServer.writeInt(0); toServer.writeChar(shape.charAt(0)); toServer.flush();
      }
      catch (IOException ex) {
        System.err.println(ex);
      }
    });
    bt8.setOnAction(e ->{
      try {
        toServer.writeInt(1); toServer.flush();
        toServer.writeInt(2); toServer.writeInt(1); toServer.writeChar(shape.charAt(0)); toServer.flush();
      }
      catch (IOException ex) {
        System.err.println(ex);
      }
    });
    bt9.setOnAction(e ->{
      try {
        toServer.writeInt(1); toServer.flush();
        toServer.writeInt(2); toServer.writeInt(2); toServer.writeChar(shape.charAt(0)); toServer.flush();
      }
      catch (IOException ex) {
        System.err.println(ex);
      }
    });
    
  
    try {
      Socket socket = new Socket("localhost", 8000);

      fromServer = new DataInputStream(socket.getInputStream());

      toServer = new DataOutputStream(socket.getOutputStream());
      
      sign = fromServer.readInt();
        if (sign == 1){
            borderPane1.setLeft(new Label("You are player X"));
            shape = "X";
        }
        else {
            borderPane1.setLeft(new Label("You are player O"));
            shape = "O";
        }
      Runnable check = new frequentCheck(socket);
      Thread thread1 = new Thread(check);
      thread1.start();
        
        
    }
    catch (IOException ex) {
      ta.appendText(ex.toString() + '\n');
    }
    
  }
  class frequentCheck implements Runnable {
      Socket socket;
      public frequentCheck(Socket socket){
          this.socket = socket;
      }
      public void run(){
        try{
            while(true){
                toServer.writeInt(2); toServer.flush();
                String gameBoard = fromServer.readUTF();
                int gameStatus = fromServer.readInt();
                String parts[] = gameBoard.split("-");
                Platform.runLater( () -> {
                    if(Integer.parseInt(parts[0])==sign) borderPane1.setRight(new Label("Other player's turn"));
                    else if(Integer.parseInt(parts[0])!=sign) borderPane1.setRight(new Label("Your Turn"));
                    if(Integer.parseInt(parts[1])==2) bt1.setText("O");
                    else if(Integer.parseInt(parts[1])==1) bt1.setText("X");
                    if(Integer.parseInt(parts[2])==2) bt2.setText("O");
                    else if(Integer.parseInt(parts[2])==1) bt2.setText("X");
                    if(Integer.parseInt(parts[3])==2) bt3.setText("O");
                    else if(Integer.parseInt(parts[3])==1) bt3.setText("X");
                    if(Integer.parseInt(parts[4])==2) bt4.setText("O");
                    else if(Integer.parseInt(parts[4])==1) bt4.setText("X");
                    if(Integer.parseInt(parts[5])==2) bt5.setText("O");
                    else if(Integer.parseInt(parts[5])==1) bt5.setText("X");
                    if(Integer.parseInt(parts[6])==2) bt6.setText("O");
                    else if(Integer.parseInt(parts[6])==1) bt6.setText("X");
                    if(Integer.parseInt(parts[7])==2) bt7.setText("O");
                    else if(Integer.parseInt(parts[7])==1) bt7.setText("X");
                    if(Integer.parseInt(parts[8])==2) bt8.setText("O");
                    else if(Integer.parseInt(parts[8])==1) bt8.setText("X");
                    if(Integer.parseInt(parts[9])==2) bt9.setText("O");
                    else if(Integer.parseInt(parts[9])==1) bt9.setText("X");
                    if(gameStatus == 0){}
                    else if(gameStatus == sign) borderPane1.setRight(new Label("You Win!"));
                    else borderPane1.setRight(new Label("You Lose"));
                    });
                try{
                    Thread.sleep(1500);
                }
                catch(InterruptedException ex){
                    ex.printStackTrace();
                }
                
            }
        }
        catch(IOException ex){
            ex.printStackTrace();
        }
      }
    }
  

    public static void main(String[] args) {
        launch();
    }

}