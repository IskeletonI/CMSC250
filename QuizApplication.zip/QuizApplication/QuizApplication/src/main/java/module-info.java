module edu.lawrence.quiz {
    requires javafx.controls;
    requires javafx.fxml;
    requires java.sql;
    requires java.base;
    
    opens edu.lawrence.applicationsql to javafx.fxml;
    exports edu.lawrence.applicationsql;
}