package edu.lawrence.quiz;



public class Quiz {
    private int id;
    private String quiz;
    
    public Quiz(int id,String quiz) {
        this.id = id;
        this.quiz = quiz;
    }
    
    public int getId() { return id; }
    
    public String toString() {
        return quiz;
    }
}
